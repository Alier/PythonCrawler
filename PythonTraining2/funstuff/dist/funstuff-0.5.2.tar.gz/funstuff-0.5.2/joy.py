print 'Joy!'
