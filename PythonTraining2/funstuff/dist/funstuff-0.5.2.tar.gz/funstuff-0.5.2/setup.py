from distutils.core import setup

setup(name = 'funstuff',
      version = '0.5.2',
      author = 'Ai Zhang',
      author_email = 'xxxxxx@gmail.com',
      description = 'Celebration of life in Python',
      py_modules = ['happy','joy'])
