print 'Happy!'
